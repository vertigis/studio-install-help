Place self-signed certs intended to further inform
the trusted root certificate store for the container.
